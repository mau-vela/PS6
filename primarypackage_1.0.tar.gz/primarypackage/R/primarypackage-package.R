#' primarypackage
#'
#' The primarypackage package creates candidate and calculate delegates  
#' @name primarypackage
#' @docType package
#' @author  Mauricio Vela: \email{mauriciovelabaron@@wustl.edu} 
#' 
#' @seealso \code{\link{createCandidate}}, \code{\link{Candidate}}, \code{\link{propNeeded}}
#'
#' 

#'
NULL